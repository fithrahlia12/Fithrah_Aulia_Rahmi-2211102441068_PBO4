import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Snake extends Actor 
{
    private int score = 0; // Variabel untuk menyimpan skor

    public Snake()
    {
        score = 0; // Inisialisasi skor awal
    }

    public void act() 
    {
        int moveAmount = 2; // Jumlah langkah per gerakan

        // Gerakan acak
        if (Greenfoot.getRandomNumber(100) < 25) 
        {
            turn(Greenfoot.getRandomNumber(90) - 30); // Putar sebanyak -30 hingga +30 derajat
        }
        move(moveAmount);

        // Cek apakah Snake memakan tikus
        if (isTouching(Mouse.class)) {
            removeTouching(Mouse.class); // Hapus tikus yang dimakan
            score += 10; // Tambahkan 10 poin ke skor
        }
        
        World world = getWorld();
        world.showText("Skor: " + score, 60, 30);

        // Cek apakah pemain memenangkan permainan (misalnya, dengan mencapai skor 100)
        if (score >= 100) {
            world.showText("Anda Menang!", world.getWidth() / 2, world.getHeight() / 2);
            Greenfoot.stop(); // Menghentikan permainan
        }
    }
}