import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Mouse extends Actor {
    private GreenfootSound eatSound;
    public Mouse() {
        eatSound = new GreenfootSound("eat.wav");
    }
    
    public void act() 
    {
        move(-2);
        if (isTouching(Snake.class)) {
            getWorld().removeObject(this);
            eatSound.play();
        }
    }
}
