import greenfoot.*;
import java.util.List;
import java.util.concurrent.Flow;
import java.util.*;

public class SnakeGame extends World 
{
    public SnakeGame() {
        super(600, 400, 1);
        this.setPaintOrder(Mouse.class, Snake.class);
        Random rnd = new Random();
        Boolean isRunning = false;
        for(int i=0; i<3; i++){
            int x = rnd.nextInt(this.getWidth()-1);
            int y = rnd.nextInt(this.getHeight()-1);
            Mouse tikus1 = new Mouse();
            tikus1.setRotation(75*rnd.nextInt(1));
            this.addObject(tikus1, x, y);
        }
        addObject(new Mouse(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        prepare();
    }

    private void prepare() {
        Bird bird = new Bird();
        addObject(bird, 100, 200);

        Mouse mouse = new Mouse();
        addObject(mouse, 400, 200);

        Snake snake = new Snake();
        addObject(snake, 300, 200);
        addObject(snake, Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        snake.setLocation(300,279);
        mouse.setLocation(482,295);
        mouse.setLocation(480,257);
        snake.setLocation(288,246);
        bird.setLocation(74,190);
        bird.setLocation(438,279);
        bird.setLocation(136,193);
        snake.setLocation(392,261);
    }
    private int frameCount = 0;
    private int mouseSpawnDelay = 80;
    // Jumlah frame antara setiap koin
    public void act() 
    {
        frameCount++;
        if (frameCount % mouseSpawnDelay == 0) 
        {
            addObject(new Mouse(), Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
    }
}

